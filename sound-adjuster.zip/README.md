# Sound-Adjuster
A Firefox browser extension to adjust tab audio with volume (gain) and stereo balance (pan) controls.
[![Download on Firefox](https://img.shields.io/badge/Firefox-Download-blue?style=for-the-badge&logo=firefox)](https://addons.mozilla.org/en-US/firefox/addon/sound-adjuster)
