browser.runtime.onInstalled.addListener(() => {
  console.log("Tab Sound Controller yüklendi.");
});
